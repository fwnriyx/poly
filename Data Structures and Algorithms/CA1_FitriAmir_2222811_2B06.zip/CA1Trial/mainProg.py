from misc import misc

misc_instance = misc()
misc.boxbox()
misc_instance.menu()
